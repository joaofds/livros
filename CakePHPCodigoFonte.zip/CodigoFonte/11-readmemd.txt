Simple plugin to implement Bootstrap in CakePHP 3
===================================================

This plugin is a fork of the Twitter Bootstrap Plugin
https://github.com/elboletaire/twbs-cake-plugin

This plugin only use CSS, dont use Less.

It also contains bake templates that will help you starting *twitter-bootstraped*
CakePHP webapps.

General Features
----------------

- Bake templates.
- Generic Bootstrap layout.

Installation
------------

### Adding the plugin

You can easily install this plugin using composer as follows:

```bash
composer require ribafs/twbs-cake-css
```

### Enabling the plugin

After adding the plugin remember to load it in your `config/bootstrap.php` file:

```php
bin/cake plugin load Bootstrap
```

This will load the CSS for you.

### Add Template to src/Controller/AppController.php

```php
    public function beforeRender(Event $event)
    {
        $this->viewBuilder()->theme('Bootstrap');
    ...
```     

### Baking views

You can bake your views using the twitter bootstrap templates bundled with this
plugin. To do so, simply specify the `bootstrap` template when baking your files:

```bash
bin/cake bake all amigos --theme Bootstrap
```

License
-------

The MIT License (MIT)
